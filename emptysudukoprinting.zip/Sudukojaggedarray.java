/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Sudukojaggedarray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a[][]=new int[9][];
		System.out.println("Enter the Suduko Values!!");
		for(int i=0;i<9;i++) {
			a[i] = new int[9];
			for(int j=0;j<a[i].length;j++) {
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("\nSudoku Board");
        System.out.println("+------+------+------+");
		for(int i=0;i<9;i++) {
			for(int j=0;j<a[i].length;j++) {
				if(j%3==0) 
					System.out.print("|");
				if(a[i][j]==0) 
					System.out.print("__");
				else
                    System.out.print(a[i][j] + " ");
			}
			System.out.println("|");
			if((i+1)%3==0) 
				System.out.println("+------+------+------+");
		}
		sc.close();
	}
}
